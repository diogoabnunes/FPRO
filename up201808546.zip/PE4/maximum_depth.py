#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  8 14:59:21 2019

@author: exame
"""

def maximum_depth(l):
#    count = 0
#    maximum = 0
#    for elem in l:
#        if elem == []:
#            count += 1
#        else:
#            count += maximum_depth(elem)
#        if count > maximum:
#            maximum = count

    l = str(l)
    count = 0
    substring = l[::-1]
    for letter in substring:
        if letter == "]": count += 1
        else: break
    return count

print(maximum_depth([[], [[]], [], [[]]])) #3
print(maximum_depth([[[], [], [[]]], [[]], [], [[]]])) #4
print(maximum_depth([[[], [], [[]]], [[[[]]]]])) #5