#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  8 14:40:37 2019

@author: exame
"""

def gcd(a,b):
    c = a % b
    if c == 0: return b
    else: return gcd(b,c)

print(gcd(25, 5)) #5
print(gcd(21, 14)) #7
print(gcd(65, 26)) #13