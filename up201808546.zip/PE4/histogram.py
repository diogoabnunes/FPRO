#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jan  8 14:51:43 2019

@author: exame
"""

def histogram(alist,bins):
    result = []
    if bins == []: return []
    for i in range(len(bins)-1):
        count = 0
        for elem in alist:
            if elem >= bins[i] and elem < bins[i+1]: count += 1
        result.append(count)
    return result

print(histogram([1, 1, 1, 4, 5, 8, 10], (0, 3, 7, 12))) #[3, 2, 2]
print(histogram([0, 3, 4, 7, 8, 1, 5], (0, 3, 7, 12))) #[2, 3, 2]
print(histogram([3, 0, 1, 5, 3, 2], (0, 3, 6))) #[3, 3]